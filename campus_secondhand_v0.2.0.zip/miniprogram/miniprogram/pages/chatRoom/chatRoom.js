// 聊天会话 + 撮合交易闭环
const app = getApp();
const db = require('../../utils/db');
const { toast } = require('../../utils/util');

Page({
  data: {
    itemId: '', itemTitle: '', price: '', seller: '', sellerAvatar: '👦',
    messages: [],
    draft: '',
    scrollTo: 'bottom',
    // 交易状态
    tradeStatus: '',        // '' 未发起 / '待完成' / '已完成'
    tradeStatusText: '',
    buyerDone: false, sellerDone: false,
    dealBtnText: '发起交易',
    _msgId: 0
  },

  onLoad(q) {
    this.setData({
      itemId: q.itemId || '',
      itemTitle: decodeURIComponent(q.title || '商品'),
      price: q.price || '',
      seller: decodeURIComponent(q.seller || '卖家')
    });
    wx.setNavigationBarTitle({ title: this.data.seller });
    // 预置演示对话
    this.pushMsg('你好，这个还在吗？', true);
    this.pushMsg('在的，诚心可小刀，校内当面交易~', false);
  },

  onDraft(e) { this.setData({ draft: e.detail.value }); },

  pushMsg(content, me, type = 'text') {
    const id = ++this.data._msgId;
    const messages = this.data.messages.concat([{ id, content, me, type }]);
    this.setData({ messages, _msgId: id, scrollTo: 'bottom' });
  },

  send() {
    const text = this.data.draft.trim();
    if (!text) return;
    this.pushMsg(text, true);
    this.setData({ draft: '' });
    // 演示：对方自动回一句
    setTimeout(() => this.pushMsg('好的，没问题 👌', false), 800);
  },

  // 顶部按钮：发起 / 查看交易
  onTradeAction() {
    if (!this.data.tradeStatus) this.startTrade();
    else this.setData({ scrollTo: 'tradeCard' });
  },

  // 发起交易
  async startTrade() {
    if ((app.globalData.authLevel || 0) < 2) {
      wx.showModal({
        title: '需要学生认证', content: '发起交易前请先完成学生认证',
        confirmText: '去认证',
        success: (r) => { if (r.confirm) wx.navigateTo({ url: '/pages/auth/auth' }); }
      });
      return;
    }
    this.setData({
      tradeStatus: '待完成', tradeStatusText: '待双方线下当面完成',
      dealBtnText: '查看交易'
    });
    this.pushMsg('已发起当面交易，请线下一手交钱一手交货，完成后双方点「我已完成」', false, 'sys');
    this.setData({ scrollTo: 'tradeCard' });

    // 写入云端交易记录（演示环境失败则忽略）
    try {
      await db.createTrade({
        itemId: this.data.itemId, itemTitle: this.data.itemTitle,
        price: Number(this.data.price) || 0,
        buyerId: app.globalData.openid, sellerName: this.data.seller
      });
    } catch (e) { console.warn('创建交易记录失败（演示可忽略）', e); }
    toast('已发起交易', 'success');
  },

  // 确认完成（当前用户视为买家）
  confirmDone() {
    if (this.data.buyerDone) { toast('你已确认，等待对方'); return; }
    this.setData({ buyerDone: true });
    this.pushMsg('买家已确认完成交易', false, 'sys');
    // 演示：对方（卖家）随后也确认
    setTimeout(() => {
      this.setData({ sellerDone: true });
      this.pushMsg('卖家已确认完成交易', false, 'sys');
      this.finishTrade();
    }, 1200);
  },

  finishTrade() {
    this.setData({
      tradeStatus: '已完成', tradeStatusText: '交易已完成',
      dealBtnText: '已完成'
    });
    this.pushMsg('🎉 交易已完成，感谢使用校园集市！记得互相评价哦', false, 'sys');
    toast('交易完成', 'success');
  }
});
