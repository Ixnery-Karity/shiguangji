// 消息列表（MVP：演示会话数据）
Page({
  data: {
    chats: [
      { id: 'c1', avatar: '👦', name: '王同学', lastMsg: '可以，一言为定 👍', time: '刚刚', unread: 1,
        itemId: 'm1', itemTitle: '高等数学 同济第七版', price: 15 },
      { id: 'c2', avatar: '👧', name: '陈同学', lastMsg: '口红全新未拆，晚上5楼下当面看？', time: '10分钟前', unread: 0,
        itemId: 'm4', itemTitle: '全新口红 色号#12', price: 60 }
    ]
  },

  openChat(e) {
    const c = this.data.chats[e.currentTarget.dataset.i];
    wx.navigateTo({
      url: `/pages/chatRoom/chatRoom?itemId=${c.itemId}` +
           `&title=${encodeURIComponent(c.itemTitle)}&price=${c.price}` +
           `&seller=${encodeURIComponent(c.name)}`
    });
  }
});
