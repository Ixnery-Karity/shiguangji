// 学生认证
const app = getApp();
const { toast, isCampusEmail, genCode } = require('../../utils/util');

const LEVEL_TEXT = { 0: '游客（未认证）', 1: '邮箱已验证', 2: '已认证学生 ✔' };

Page({
  data: {
    authLevel: 0,
    levelText: '',
    email: '', code: '', devCode: '',
    codeSent: false, counting: false, countdown: 60,
    maskedEmail: '',
    certImg: '', certSubmitted: false
  },

  onShow() {
    const lv = app.globalData.authLevel || 0;
    const u = app.globalData.userInfo || {};
    this.setData({
      authLevel: lv,
      levelText: LEVEL_TEXT[lv],
      maskedEmail: u.email ? this.mask(u.email) : ''
    });
  },

  mask(email) {
    const [name, domain] = email.split('@');
    const head = name.slice(0, 2);
    return `${head}****@${domain}`;
  },

  onEmail(e) { this.setData({ email: e.detail.value }); },
  onCode(e) { this.setData({ code: e.detail.value }); },

  // 发送验证码（演示：本地生成；真实项目应由后端云函数发邮件）
  sendCode() {
    if (this.data.counting) return;
    if (!isCampusEmail(this.data.email)) {
      toast('请输入正确的校园邮箱（edu.cn 后缀）');
      return;
    }
    const c = genCode();
    this._code = c;
    this.setData({ codeSent: true, devCode: c, counting: true, countdown: 60 });
    toast('验证码已发送', 'success');
    this.timer = setInterval(() => {
      const n = this.data.countdown - 1;
      if (n <= 0) { clearInterval(this.timer); this.setData({ counting: false }); }
      else this.setData({ countdown: n });
    }, 1000);
  },

  // 校验邮箱验证码 → 升级为 level 1
  verifyEmail() {
    if (this.data.code !== this._code) { toast('验证码不正确'); return; }
    this.saveLevel(1, { email: this.data.email }).then(() => {
      this.setData({ authLevel: 1, levelText: LEVEL_TEXT[1], maskedEmail: this.mask(this.data.email) });
      toast('邮箱验证成功', 'success');
    });
  },

  uploadCert() {
    wx.chooseMedia({
      count: 1, mediaType: ['image'],
      success: (res) => this.setData({ certImg: res.tempFiles[0].tempFilePath })
    });
  },

  // 提交学生证审核。演示：直接标记通过；真实项目应上传+后台人工审核
  submitCert() {
    if (this.data.authLevel < 1) { toast('请先完成第一步邮箱验证'); return; }
    if (!this.data.certImg) { toast('请先上传学生证照片'); return; }
    this.setData({ certSubmitted: true });
    wx.showLoading({ title: '提交中…' });
    // 演示环境：模拟审核通过。生产环境应写 authRecords 待审核，由后台通过后再升级
    setTimeout(() => {
      this.saveLevel(2, {}).then(() => {
        wx.hideLoading();
        this.setData({ authLevel: 2, levelText: LEVEL_TEXT[2] });
        wx.showModal({
          title: '认证通过', content: '恭喜！你已成为认证学生，现在可以发布与交易了。',
          showCancel: false, confirmText: '好的',
          success: () => wx.navigateBack()
        });
      });
    }, 1500);
  },

  // 写入用户认证等级
  async saveLevel(level, extra) {
    app.globalData.authLevel = level;
    if (app.globalData.userInfo) {
      app.globalData.userInfo = Object.assign({}, app.globalData.userInfo, { authLevel: level }, extra);
    }
    const db = require('../../utils/db');
    if (db.hasCloud() && app.globalData.openid) {
      try {
        const cdb = wx.cloud.database();
        await cdb.collection('users').where({ _openid: app.globalData.openid })
          .update({ data: Object.assign({ authLevel: level }, extra) });
      } catch (e) { console.warn('保存认证等级失败（演示环境可忽略）', e); }
    }
  },

  onUnload() { if (this.timer) clearInterval(this.timer); }
});
