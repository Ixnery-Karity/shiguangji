// utils/db.js —— 数据访问层
// 设计：优先云数据库；若云环境未就绪或查询异常，则回退到本地 mock，
//       保证未接云开发时页面与流程仍可演示。
const mock = require('./mock');

function coll(name) {
  return wx.cloud.database().collection(name);
}
function hasCloud() {
  return !!(wx.cloud && wx.cloud.database);
}

// 商品列表（支持分类、关键词）
async function listItems({ category = '全部', keyword = '' } = {}) {
  if (hasCloud()) {
    try {
      const db = wx.cloud.database();
      const _ = db.command;
      const where = { status: '在售' };
      if (category && category !== '全部') where.category = category;
      let q = coll('items').where(where);
      const res = await q.orderBy('createdAt', 'desc').limit(50).get();
      let data = res.data || [];
      if (keyword) data = data.filter(i => (i.title || '').indexOf(keyword) >= 0);
      if (data.length) return data;
    } catch (e) {
      console.warn('[db] listItems 回退 mock：', e.errMsg || e);
    }
  }
  // 回退 mock
  let data = mock.ITEMS.slice();
  if (category && category !== '全部') data = data.filter(i => i.category === category);
  if (keyword) data = data.filter(i => i.title.indexOf(keyword) >= 0);
  return data;
}

// 商品详情
async function getItem(id) {
  if (hasCloud()) {
    try {
      const res = await coll('items').doc(id).get();
      if (res.data) return res.data;
    } catch (e) {
      console.warn('[db] getItem 回退 mock：', e.errMsg || e);
    }
  }
  return mock.ITEMS.find(i => i._id === id) || null;
}

// 发布商品
async function addItem(item) {
  if (!hasCloud()) throw new Error('云环境未就绪，无法真实发布');
  const db = wx.cloud.database();
  const data = Object.assign({
    status: '在售', createdAt: db.serverDate(), images: [], condition: '九成新'
  }, item);
  return coll('items').add({ data });
}

// 我的发布
async function myItems(openid) {
  if (hasCloud()) {
    try {
      const res = await coll('items').where({ _openid: openid })
        .orderBy('createdAt', 'desc').get();
      return res.data || [];
    } catch (e) { console.warn('[db] myItems 回退：', e.errMsg || e); }
  }
  return [];
}

// 交易：发起
async function createTrade(trade) {
  if (!hasCloud()) throw new Error('云环境未就绪');
  const db = wx.cloud.database();
  return coll('trades').add({
    data: Object.assign({
      status: '待完成', buyerDone: false, sellerDone: false,
      createdAt: db.serverDate()
    }, trade)
  });
}

// 交易：确认完成（buyer/seller 之一）
async function confirmTrade(tradeId, role) {
  if (!hasCloud()) throw new Error('云环境未就绪');
  const patch = role === 'buyer' ? { buyerDone: true } : { sellerDone: true };
  return coll('trades').doc(tradeId).update({ data: patch });
}

// 我的交易列表
async function myTrades(openid) {
  if (hasCloud()) {
    try {
      const db = wx.cloud.database();
      const _ = db.command;
      const res = await coll('trades')
        .where(_.or([{ buyerId: openid }, { sellerId: openid }]))
        .orderBy('createdAt', 'desc').get();
      return res.data || [];
    } catch (e) { console.warn('[db] myTrades 回退：', e.errMsg || e); }
  }
  return [];
}

module.exports = {
  hasCloud, listItems, getItem, addItem, myItems,
  createTrade, confirmTrade, myTrades
};
